# Work Calendar — University of Toronto
## SAP BTP Deployment Package

Self-contained single-page HTML application. No build step required.
No external dependencies — all fonts and logic are embedded.

---

## Option A — HTML5 Application Repository (Recommended)

Serverless deployment — no CF runtime needed.

### Prerequisites
- CF CLI installed
- HTML5 Apps CF CLI Plugin: `cf install-plugin -r CF-Community "html5-plugin"`
- Logged in to BTP CF: `cf login`

### Deploy
```bash
cd workcalendar
cf html5-push
```

The app is uploaded to the HTML5 App Repository and accessible
via the BTP Launchpad or directly from the HTML5 Apps cockpit.

---

## Option B — Cloud Foundry Staticfile Buildpack

Deploys as a running CF application with a public URL.

### Prerequisites
- CF CLI installed and logged in to BTP CF

### Deploy
```bash
cf push
```

App URL will be printed after deployment:
`https://work-calendar-<org>-<space>.cfapps.<region>.hana.ondemand.com`

---

## Option C — MTA Deployment

Use the Multi-Target Application approach for structured BTP deployment.

### Prerequisites
- CF CLI + MTA CF CLI Plugin: `cf add-plugin-repo CF-Community https://plugins.cloudfoundry.org && cf install-plugin multiapps`
- MBT build tool: `npm install -g mbt`

### Deploy
```bash
mbt build
cf deploy mta_archives/workcalendar_1.0.0.mtar
```

---

## Files

| File | Purpose |
|------|---------|
| `workcalendar/index.html` | The complete application — single file |
| `workcalendar/manifest.json` | SAP app descriptor (required for HTML5 Repo) |
| `workcalendar/xs-app.json` | App Router routing config |
| `workcalendar/Staticfile` | Staticfile buildpack marker |
| `manifest.yml` | CF push manifest (Option B) |
| `mta.yaml` | MTA deployment descriptor (Option C) |

---

## Security Notes

- No backend, no database, no authentication built-in.
- All data (schedules, holidays, theme preference, logo) is stored in browser localStorage.
- Admin PIN is stored as SHA-256 hash in localStorage — raw PIN never persisted.
- Recommended: deploy behind BTP Identity Authentication Service (IAS) or
  an App Router with XSUAA for SSO if user authentication is required.
- Add the recommended HTTP response headers from the comment block at the
  top of index.html to your web server or CF app router configuration.
